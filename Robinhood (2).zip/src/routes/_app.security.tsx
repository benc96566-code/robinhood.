import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ChevronRight, Fingerprint, KeyRound, Smartphone, ShieldCheck, History } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/lib/external-supabase";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/_app/security")({
  component: Security,
});

function Security() {
  const [faceId, setFaceId] = useState(true);
  const [tfa, setTfa] = useState(true);
  const { user } = useAuth();
  const [pwOpen, setPwOpen] = useState(false);
  const [devicesOpen, setDevicesOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [saving, setSaving] = useState(false);

  const changePassword = async () => {
    if (newPw.length < 8) return toast.error("Password must be at least 8 characters");
    if (newPw !== confirmPw) return toast.error("Passwords do not match");
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: newPw });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    setNewPw(""); setConfirmPw(""); setPwOpen(false);
  };

  const sendReset = async () => {
    if (!user?.email) return toast.error("No email on file");
    const { error } = await supabase.auth.resetPasswordForEmail(user.email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) return toast.error(error.message);
    toast.success("Reset link sent to your email");
  };

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <div className="flex items-center gap-2">
        <Link to="/profile" className="grid h-10 w-10 place-items-center rounded-full hover:bg-surface">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <h1 className="text-xl font-bold">Security</h1>
      </div>
      <div className="card-elevated mt-6 divide-y divide-border overflow-hidden">
        <Toggle icon={Fingerprint} label="Face ID" on={faceId} onChange={(v) => { setFaceId(v); toast.success(`Face ID ${v ? "enabled" : "disabled"}`); }} />
        <Nav icon={KeyRound} label="Change password" onClick={() => setPwOpen(true)} />
        <Toggle icon={ShieldCheck} label="Two-Factor Authentication" on={tfa} onChange={(v) => { setTfa(v); toast.success(`Two-factor ${v ? "enabled" : "disabled"}`); }} />
        <Nav icon={Smartphone} label="Trusted devices" onClick={() => setDevicesOpen(true)} />
        <Nav icon={History} label="Login history" onClick={() => setHistoryOpen(true)} />
      </div>

      <Dialog open={pwOpen} onOpenChange={setPwOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Change password</DialogTitle>
            <DialogDescription>Set a new password for your account.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="New password" className="h-11 w-full rounded-xl border border-border bg-background px-3 outline-none focus:border-primary" />
            <input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} placeholder="Confirm new password" className="h-11 w-full rounded-xl border border-border bg-background px-3 outline-none focus:border-primary" />
            <button onClick={changePassword} disabled={saving} className="btn-primary-glow inline-flex h-11 w-full items-center justify-center rounded-2xl text-sm font-semibold">
              {saving ? "Updating…" : "Update password"}
            </button>
            <button onClick={sendReset} className="inline-flex h-11 w-full items-center justify-center rounded-2xl border border-border bg-card text-sm font-semibold">
              Email me a reset link
            </button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={devicesOpen} onOpenChange={setDevicesOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Trusted devices</DialogTitle>
            <DialogDescription>Devices currently signed in to your account.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <div className="rounded-xl border border-border bg-card p-3">
              <div className="font-semibold">This device</div>
              <div className="mt-1 text-xs text-muted-foreground break-all">{typeof navigator !== "undefined" ? navigator.userAgent : ""}</div>
              <div className="mt-1 text-xs text-primary">Active now</div>
            </div>
            <button
              onClick={async () => { await supabase.auth.signOut({ scope: "others" as any }); toast.success("Signed out other devices"); setDevicesOpen(false); }}
              className="mt-2 inline-flex h-11 w-full items-center justify-center rounded-2xl border border-border bg-card text-sm font-semibold text-destructive"
            >
              Sign out all other devices
            </button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Login history</DialogTitle>
            <DialogDescription>Recent sign-in activity on your account.</DialogDescription>
          </DialogHeader>
          <ul className="space-y-2 text-sm">
            <li className="rounded-xl border border-border bg-card p-3">
              <div className="font-semibold">Current session</div>
              <div className="mt-1 text-xs text-muted-foreground">
                {user?.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleString() : "Just now"}
              </div>
            </li>
            <li className="rounded-xl border border-border bg-card p-3">
              <div className="font-semibold">Account created</div>
              <div className="mt-1 text-xs text-muted-foreground">
                {user?.created_at ? new Date(user.created_at).toLocaleString() : "—"}
              </div>
            </li>
          </ul>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Toggle({ icon: Icon, label, on, onChange }: { icon: React.ComponentType<{ className?: string }>; label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <Icon className="h-5 w-5 text-muted-foreground" />
      <span className="flex-1 text-[15px] font-medium">{label}</span>
      <button onClick={() => onChange(!on)} className={`h-7 w-12 rounded-full transition ${on ? "bg-primary" : "bg-muted"}`}>
        <div className={`h-6 w-6 rounded-full bg-white shadow transition ${on ? "translate-x-5" : "translate-x-0.5"}`} />
      </button>
    </div>
  );
}
function Nav({ icon: Icon, label, onClick }: { icon: React.ComponentType<{ className?: string }>; label: string; onClick?: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-surface">
      <Icon className="h-5 w-5 text-muted-foreground" />
      <span className="flex-1 text-[15px] font-medium">{label}</span>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </button>
  );
}
