import { createFileRoute, Link } from "@tanstack/react-router";
import { PriceChart } from "@/components/PriceChart";
import { AssetIcon } from "@/components/AssetIcon";
import { findAsset, seriesFor } from "@/lib/market-data";
import { money, pct } from "@/lib/format";
import { useAccount, useOrders } from "@/lib/api";
import { useMemo } from "react";

export const Route = createFileRoute("/_app/portfolio")({
  component: Portfolio,
});

function Portfolio() {
  const { data: account } = useAccount();
  const { data: orders } = useOrders();

  const cash = Number(account?.balance ?? 0);

  const holdings = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of orders ?? []) {
      if (o.status !== "filled" && o.status !== "open") continue;
      const q = Number(o.quantity) * (o.side === "sell" ? -1 : 1);
      map.set(o.symbol, (map.get(o.symbol) ?? 0) + q);
    }
    return Array.from(map.entries())
      .filter(([, q]) => q > 0.0000001)
      .map(([symbol, shares]) => {
        const asset = findAsset(symbol);
        return asset ? { symbol, shares, asset, value: asset.price * shares } : null;
      })
      .filter(Boolean) as { symbol: string; shares: number; asset: NonNullable<ReturnType<typeof findAsset>>; value: number }[];
  }, [orders]);

  const stocks = holdings.filter((h) => h.asset.kind !== "crypto").reduce((s, h) => s + h.value, 0);
  const crypto = holdings.filter((h) => h.asset.kind === "crypto").reduce((s, h) => s + h.value, 0);
  const invested = stocks + crypto;
  const total = invested + cash;

  return (
    <div className="mx-auto max-w-md px-5 pt-8">
      <div>
        <div className="text-xs font-medium text-muted-foreground">Your portfolio</div>
        <div className="mt-0.5 text-3xl font-extrabold tracking-tight">{money(total)}</div>
        <div className="mt-1 text-sm font-semibold text-muted-foreground">
          {invested > 0 ? `${money(invested)} invested · ${money(cash)} cash` : `${money(cash)} in cash`}
        </div>
      </div>

      <div className="mt-6">
        <PriceChart data={seriesFor("PF", 60)} height={180} />
      </div>

      <div className="mt-6 grid grid-cols-3 gap-3">
        <Bucket label="Stocks" value={money(stocks)} />
        <Bucket label="Crypto" value={money(crypto)} />
        <Bucket label="Cash" value={money(cash)} />
      </div>

      {holdings.length > 0 ? (
        <>
          <h2 className="mt-8 text-lg font-bold tracking-tight">Allocation</h2>
          <div className="mt-3 card-elevated p-4">
            {holdings.map((h) => {
              const p = total > 0 ? (h.value / total) * 100 : 0;
              return (
                <div key={h.symbol} className="py-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex min-w-0 items-center gap-2 font-semibold">
                      <AssetIcon symbol={h.symbol} size={22} />
                      <span className="truncate">{h.asset.name}</span>
                    </div>
                    <span className="shrink-0 text-muted-foreground">{p.toFixed(1)}%</span>
                  </div>
                  <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${p}%` }} />
                  </div>
                </div>
              );
            })}
          </div>

          <h2 className="mt-8 text-lg font-bold tracking-tight">Holdings</h2>
          <ul className="mt-3 space-y-1">
            {holdings.map((h) => (
              <li key={h.symbol}>
                <Link to="/asset/$symbol" params={{ symbol: h.symbol }} className="flex items-center gap-3 rounded-2xl p-3 hover:bg-surface">
                  <AssetIcon symbol={h.symbol} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-semibold">{h.asset.name}</div>
                    <div className="text-xs text-muted-foreground">{h.shares.toLocaleString(undefined, { maximumFractionDigits: 6 })} shares</div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="text-sm font-semibold">{money(h.value)}</div>
                    <div className={`text-xs font-semibold ${h.asset.change >= 0 ? "text-primary" : "text-destructive"}`}>{pct(h.asset.change)}</div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </>
      ) : (
        <div className="card-elevated mt-8 p-6 text-center">
          <h2 className="text-base font-bold">No holdings yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">Start investing to build your portfolio.</p>
          <Link to="/markets" className="btn-primary-glow mt-4 inline-flex h-11 items-center justify-center rounded-2xl px-5 text-sm font-semibold">
            Browse markets
          </Link>
        </div>
      )}
    </div>
  );
}

function Bucket({ label, value }: { label: string; value: string }) {
  return (
    <div className="card-elevated p-3">
      <div className="text-[11px] font-medium text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-sm font-bold">{value}</div>
    </div>
  );
}
