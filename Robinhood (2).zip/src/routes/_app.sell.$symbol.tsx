import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { findAsset } from "@/lib/market-data";
import { money } from "@/lib/format";
import { useMemo, useState } from "react";
import { ArrowLeft, AlertCircle, Clock } from "lucide-react";
import { AssetIcon } from "@/components/AssetIcon";
import { toast } from "sonner";
import { useOrders, usePlaceSellOrder } from "@/lib/api";

export const Route = createFileRoute("/_app/sell/$symbol")({
  component: Sell,
  loader: ({ params }) => {
    const a = findAsset(params.symbol);
    if (!a) throw notFound();
    return { symbol: params.symbol.toUpperCase() };
  },
});

function Sell() {
  const { symbol } = Route.useLoaderData();
  const a = findAsset(symbol)!;
  const nav = useNavigate();
  const [qty, setQty] = useState("1");
  const q = Number(qty) || 0;
  const est = q * a.price;

  const { data: orders } = useOrders();
  const held = useMemo(() => {
    if (!orders) return 0;
    return orders
      .filter((o) => o.symbol === a.symbol)
      .reduce((sum, o) => {
        if (o.side === "buy" && o.status === "filled") return sum + Number(o.quantity);
        if (o.side === "sell" && (o.status === "filled" || o.status === "pending")) return sum - Number(o.quantity);
        return sum;
      }, 0);
  }, [orders, a.symbol]);

  const insufficient = q > held;
  const place = usePlaceSellOrder();

  const submit = async () => {
    if (q <= 0) return toast.error("Enter a quantity");
    if (insufficient) return toast.error(`You only hold ${held} ${a.symbol}`);
    try {
      await place.mutateAsync({ symbol: a.symbol, quantity: q, price: a.price });
      toast.success(`Sell scheduled — completes within 24h`);
      nav({ to: "/orders" });
    } catch (e: any) {
      toast.error(e?.message ?? "Sell failed");
    }
  };

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <div className="flex items-center gap-2">
        <Link to="/asset/$symbol" params={{ symbol }} className="grid h-10 w-10 place-items-center rounded-full hover:bg-surface">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div className="flex items-center gap-2">
          <AssetIcon symbol={symbol} size={28} />
          <span className="text-lg font-bold">Sell {a.name}</span>
        </div>
      </div>

      <div className="mt-8 text-center">
        <div className="text-xs font-medium text-muted-foreground">Quantity</div>
        <input
          inputMode="decimal"
          value={qty}
          onChange={(e) => setQty(e.target.value.replace(/[^\d.]/g, ""))}
          className="mt-2 w-full bg-transparent text-center text-5xl font-extrabold tracking-tight outline-none"
        />
      </div>

      <div className="card-elevated mt-6 p-4 text-sm">
        <Row label="Order type" value="Market" />
        <Row label="Est. price" value={money(a.price)} />
        <Row label="You hold" value={`${held} ${a.symbol}`} />
        <div className="my-2 border-t border-border" />
        <Row label="Est. proceeds" value={money(est)} bold />
      </div>

      <div className="mt-4 flex items-start gap-2 rounded-2xl border border-primary/30 bg-primary/5 p-3 text-sm">
        <Clock className="mt-0.5 h-4 w-4 text-primary" />
        <div className="text-xs text-muted-foreground">
          Sell orders fill at a random time <b>between 1 and 24 hours</b> after submission. Proceeds credit to your cash balance on fill.
        </div>
      </div>

      {q > 0 && insufficient && (
        <div className="mt-3 flex items-start gap-2 rounded-2xl border border-destructive/40 bg-destructive/10 p-3 text-sm">
          <AlertCircle className="mt-0.5 h-4 w-4 text-destructive" />
          <div className="text-xs text-destructive">You only hold {held} {a.symbol}.</div>
        </div>
      )}

      <button
        onClick={submit}
        disabled={place.isPending || insufficient || q <= 0}
        className="mt-6 inline-flex h-14 w-full items-center justify-center rounded-2xl bg-destructive font-semibold text-destructive-foreground hover:brightness-110 disabled:opacity-70"
      >
        {place.isPending ? "Placing…" : insufficient ? "Not enough shares" : "Place sell order"}
      </button>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className={bold ? "font-bold" : "font-semibold"}>{value}</span>
    </div>
  );
}
